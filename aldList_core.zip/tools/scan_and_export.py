#!/usr/bin/env python3
"""
[Scan 단계]
- CSV 파일을 관찰해서 '파일 단위 사실 정보'만 생성한다.

✅ 생성하는 것
- dataset_id (filename 기반)
- filename, path(DATA_DIR 상대), size_bytes, mtime
- columns (헤더 문자열 리스트)
- columns_union / intersection / by_file

❌ 절대 하지 않는 것
- 컬럼 의미 해석(type/category 등)
- 통계 계산
- semantic_type 추정
- 설명/문서 생성

출력:
- metadata/datasets.json (Registry 입력)
- metadata/columns_*.json (보조 산출물)
"""
from __future__ import annotations

import csv
import json
import hashlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Set, Dict

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
OUT_DIR = PROJECT_ROOT / "metadata"
OUT_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class DatasetMeta:
    dataset_id: str
    path: str
    filename: str
    size_bytes: int
    mtime: float
    columns: List[str]


def read_header(p: Path) -> List[str]:
    with p.open("r", encoding="utf-8-sig", newline="") as f:
        r = csv.reader(f)
        return next(r)


def make_dataset_id(p: Path) -> str:
    # filename 기반으로 dataset_id 생성 (경로와 무관하게 동일한 ID 생성)
    # 이렇게 하면 로컬과 배포 환경에서 동일한 dataset_id가 생성됨
    filename = p.name
    h = hashlib.sha1(filename.encode("utf-8")).hexdigest()[:12]
    return f"ds_{h}"


def main():
    files = sorted(DATA_DIR.glob("*.csv"))
    if not files:
        raise SystemExit(f"No CSV files in {DATA_DIR}")

    metas: List[DatasetMeta] = []
    columns_by_file: Dict[str, List[str]] = {}
    col_sets: List[Set[str]] = []

    for p in files:
        try:
            st = p.stat()
            cols = read_header(p)
            
            # DATA_DIR 기준 상대 경로 저장 (배포 환경 호환성)
            try:
                # DATA_DIR 기준 상대 경로 계산
                rel_path = p.relative_to(DATA_DIR)
                path_to_store = str(rel_path)
            except ValueError:
                # DATA_DIR 밖에 있으면 filename만 저장
                path_to_store = p.name

            metas.append(
                DatasetMeta(
                    dataset_id=make_dataset_id(p),
                    path=path_to_store,  # 상대 경로 또는 filename만 저장
                    filename=p.name,
                    size_bytes=st.st_size,
                    mtime=st.st_mtime,
                    columns=cols,
                )
            )

            columns_by_file[str(p)] = cols
            col_sets.append(set(cols))
            print(f"✓ {p.name} ({len(cols)} cols)")
        except Exception as e:
            print(f"✗ {p.name} -> {e}")

    union = sorted(set().union(*col_sets)) if col_sets else []
    inter = sorted(set.intersection(*col_sets)) if col_sets else []

    # 메타데이터 저장
    (OUT_DIR / "datasets.json").write_text(
        json.dumps([asdict(m) for m in metas], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    (OUT_DIR / "columns_by_file.json").write_text(
        json.dumps(columns_by_file, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    (OUT_DIR / "columns_union.json").write_text(
        json.dumps(union, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    
    (OUT_DIR / "columns_intersection.json").write_text(
        json.dumps(inter, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\n" + "="*50)
    print(f"✓ 처리 완료: {len(metas)}개 파일")
    print(f"✓ 전체 컬럼 수: {len(union)}개")
    print(f"✓ 공통 컬럼 수: {len(inter)}개")
    print(f"✓ 저장 위치: {OUT_DIR}")
    print("="*50)


if __name__ == "__main__":
    main()





